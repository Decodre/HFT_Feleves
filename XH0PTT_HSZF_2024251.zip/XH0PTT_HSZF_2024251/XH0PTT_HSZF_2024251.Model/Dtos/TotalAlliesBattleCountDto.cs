﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XH0PTT_HSZF_2024251.Model.Dtos
{
    public class TotalAlliesBattleCountDto
    {
        public string HouseName { get; set; }
        public int TotalBattleCount { get; set; }
    }
}
