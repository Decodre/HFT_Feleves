﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XH0PTT_HSZF_2024251.Model.Dtos
{
    public class HouseWithMostAlliesDto
    {
        public int AlliesCount { get; set; }
        public string Name { get; set; }
    }
}
